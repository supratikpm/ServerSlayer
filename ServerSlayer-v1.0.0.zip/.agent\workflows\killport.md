---
description: Kill the process listenining on a specific port.
---
# Kill Specific Port

1.  **Identify and Kill**
    Replace `<PORT>` with the desired port number.
    ```bash
    python .agent/tools/server_slayer_tools.py kill --port <PORT>
    ```
